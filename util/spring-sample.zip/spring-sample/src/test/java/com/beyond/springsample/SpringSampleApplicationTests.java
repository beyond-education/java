package com.beyond.springsample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
